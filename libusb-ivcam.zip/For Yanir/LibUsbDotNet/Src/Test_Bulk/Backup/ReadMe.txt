USB Test_Bulk Application 
-------------------------
The Test_Bulk application is designed to work with specific hardware.
Any attempt to use this application on a usb device that was not 
designed for it will produce unpredictable result.

The Benchmark device firmware can be used with the Test_Bulk application.
See the <LibUsbDotNet Install Directory>\Benchmark\Firmware.Pic.
