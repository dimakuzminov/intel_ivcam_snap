﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LibUsbDotNet;
using LibUsbDotNet.Main;
using System.Text.RegularExpressions;
using System.Windows.Forms.Layout;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using enums_and_utils;
using LibUsbDotNet.DeviceNotify;
using System.Threading;
using System.ComponentModel;
using ModelTypes;
using System.IO;
//using CommandsInputManager.Interfaces;
//using CommandsInputManager;
using LibUsbDotNet.WinUsb;

namespace lib_usb_net_wrapper
{
    
    public class usb_lib_wrapper // : IPlayer//: ISynchronizeInvoke
    {
        private bool initialized;
        private bool depthInitialized;
        private bool colorInitialized;
        private bool isInitialized;
        private bool autoDQ;
        private bool runStarts;
        private bool depthRunStarts;
        private bool colorRunStarts;
        private bool depthIsInitialized;
        private bool colorIsInitialized;
        private bool depthIsSetStreamConfig;
        private bool colorIsSetStreamConfig;
        
        private UsbDevice MyUsbDevice;
        private UsbEndpointReader epControl;
        private UsbEndpointWriter m_pUsbEpRegOut;
        private UsbEndpointReader m_pUsbEpRegIn;
        private UsbEndpointReader epTextureVideo;
        private UsbEndpointReader epIRVideo;
        
        IntPtr depthFrame = IntPtr.Zero;
        IntPtr colorFrame = IntPtr.Zero;

        uint m_depthFrameCount = 0;
	    uint m_rgbFrameCount = 0;

        const int kStreamCount = 2;
        const int kWidth = 1920; 
        const int kHeight = 1080;

        int m_dataSize;
	    uint[] m_frame_Size;
	    byte[] reg_buff;
	    int m_reg_buff_Size;

        private Thread main;
        private Thread depthThread;
        private Thread colorThread;

        int PID;
        int VID;

        private AutoResetEvent depthFrameArrived = new AutoResetEvent(false);
        private AutoResetEvent colorFrameArrived = new AutoResetEvent(false);
        private AutoResetEvent dataArrived = new AutoResetEvent(false);

        private AutoResetEvent DeviceNotifyEventArrived = new AutoResetEvent(false);
        private AutoResetEvent DeviceNotifyEventRemoved = new AutoResetEvent(false);
        private AutoResetEvent closeEvent = new AutoResetEvent(false);

        public event EventHandler DeviceStatusChanged;
        //public event DepthFrameArrived DepthFrameArrivedCompleted;
        //public event ColorFrameArrived ColorFrameArrivedCompleted;
                
        public IDeviceNotifier UsbDeviceNotifier = DeviceNotifier.OpenDeviceNotifier();
        
        string logger;
        int dataCallbackIndex = 0;
        int depthCallbackIndex = 0;
        int colorCallbackIndex = 0;

        Queue<byte[]> temp = new Queue<byte[]>(5);

        FileInfo fileInfo;
        int headerSize = 0;
        int m_Skip = 1;

        private Mutex mut = new Mutex();

        public usb_lib_wrapper() 
        {
            try
            {
                UsbDeviceNotifier.OnDeviceNotify += OnDeviceNotifyEvent;
                
                DeviceData deviceData = EnumsAndUtils.GetDevicePidVid(EnumsAndUtils.CheckDeviceType());
                VID = deviceData.VID;
                PID = deviceData.PID;

                m_frame_Size = new uint[kStreamCount];
                m_dataSize = kWidth * kHeight * 2;
                
                //depthFrame = Marshal.AllocHGlobal(m_dataSize);
                
                InitLogger();

                main = new Thread(DeviceChangedWorker);
                main.Start();
            }
            catch { }
        }

        public usb_lib_wrapper(int headerSize) : this()
        {
            this.headerSize = headerSize;
        }

        public bool InitUSB()
        {
            try
            {
                WriteToLog("Open USB device --- Start");
                
                MyUsbDevice = UsbDevice.OpenUsbDevice(new UsbDeviceFinder(VID, PID));                                

                if (MyUsbDevice != null)
                {
                    WriteToLog("Success: Open USB device");                                       

                    IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;
                    if (!ReferenceEquals(wholeUsbDevice, null))
                    {
                        wholeUsbDevice.SetConfiguration(1);
                        wholeUsbDevice.ClaimInterface(0);
                    }
                    else
                        WriteToLog("Fail: SetConfiguration");

                    MapAndOpenEndpoints();
                    
                    return true;
                }
                else
                    WriteToLog("Fail: Open USB device");
            }
            catch (Exception exp) 
            { 
                MessageBox.Show(exp.Message);
                WriteToLog("Open USB device, exception:" + exp.Message);
            }
            
            return false;
        }

        public void DeviceChangedWorker()
        {
            int res;

            while (main.IsAlive)
            {
                res = WaitHandle.WaitAny(new WaitHandle[] { DeviceNotifyEventArrived, DeviceNotifyEventRemoved, closeEvent }, -1);

                IVEventArgs e = new IVEventArgs();
                switch (res)
                {
                    case 0:
                        // Connected Event
                        e.IsDeviceConnected = true;
                        DeviceStatusChanged(this, e);
                        break;
                    case 1:
                        // Not Connected Event
                        e.IsDeviceConnected = false;
                        DeviceStatusChanged(this, e);
                        break;
                    case 2:
                        // Close Event
                        return;
                    case WaitHandle.WaitTimeout:
                        // Timeout
                        break;
                }
            }
        }

        public void OnDeviceNotifyEvent(object sender, DeviceNotifyEventArgs e)
        {
            if (e.EventType == LibUsbDotNet.DeviceNotify.EventType.DeviceArrival)
            {
                if (e.Device != null)
                {
                    //VID = e.Device.IdVendor;
                    //PID = e.Device.IdProduct;
                }

                InitUSB();

                DeviceNotifyEventArrived.Set();
            }

            if (e.EventType == LibUsbDotNet.DeviceNotify.EventType.DeviceRemoveComplete)
            {
                CloseDevice(false);

                DeviceNotifyEventRemoved.Set();
            }
        }

        private void MapAndOpenEndpoints()
        {
            try
            {
                WriteToLog("MapAndOpenEndpoints: Start");

                string endpointsDirectory = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
                string endpointsFile = string.Format("{0}\\Endpoints\\Endpoints Config.ini", endpointsDirectory);

                if (!File.Exists(endpointsFile))
                {
                    return;
                }

                IniFile ini = new IniFile();
                ini.Load(endpointsFile);

                IniFile.IniSection epointsSettingsSection = ini.GetSection("ENDPOINTS_SETTINGS");

                foreach (IniFile.IniSection.IniKey item in epointsSettingsSection.Keys)
                {
                    switch (item.Name)
                    {
                        //case "Control": 
                        //// open control endpoint - not relevant
                        //    epControl = OpenEndpoint(item.Name, item.Value, new EventHandler<EndpointDataEventArgs>(DefaultOnDataReceived));   
                        //    break;
                        case "IRVideoEp":
                            // open depth endpoint - read    
                            epIRVideo = OpenReadEndpoint(item.Name, item.Value, new EventHandler<EndpointDataEventArgs>(OnDepthFrameReceived), false, m_dataSize);
                            break;
                        case "DataInEp":
                            // open data in endpoint - read
                            m_pUsbEpRegIn = OpenReadEndpoint(item.Name, item.Value, new EventHandler<EndpointDataEventArgs>(OnDataReceived), true);
                            break;
                        case "TextureVideoEp":
                            // open texture endpoint - read
                            epTextureVideo = OpenReadEndpoint(item.Name, item.Value, new EventHandler<EndpointDataEventArgs>(OnTextureFrameReceived), false, m_dataSize);
                            break;
                        case "DataOutEp":
                            // open data out endpoint - write
                            int epNumber = Convert.ToInt32(item.Value);

                            WriteEndpointID wepId = (WriteEndpointID)(epNumber | 0x00);
                            m_pUsbEpRegOut = MyUsbDevice.OpenEndpointWriter(wepId);

                            if (m_pUsbEpRegOut != null)
                                WriteToLog("Success: Open Write (OUT) Endpoint " + epNumber);

                            break;
                    }
                }
            }
            catch(Exception exp) 
            {
                WriteToLog("MapAndOpenEndpoints: exception, " + exp.Message);
            }
        }

        private UsbEndpointReader OpenReadEndpoint(string endpointName, string epNum, EventHandler<EndpointDataEventArgs> readCallback, bool enableCallback = false, int dataSize = 0)
        {
            bool epExist = epNum != "-1";
            UsbEndpointReader epReader = null;

            try
            {
                if (epExist)
                {
                    int epNumber = Convert.ToInt32(epNum);
                    
                    ReadEndpointID epId = (ReadEndpointID)(epNumber | 0x80);
                    epReader = dataSize > 0 ? MyUsbDevice.OpenEndpointReader(epId, dataSize) : MyUsbDevice.OpenEndpointReader(epId);

                    if (epReader.EndpointInfo != null)
                    {
                        WriteToLog("Success: Open Read (IN) Endpoint " + epNumber);
                        epReader.Flush();
                        epReader.DataReceived += new EventHandler<EndpointDataEventArgs>(readCallback);

                        if (enableCallback)
                            epReader.DataReceivedEnabled = true;
                    }
                }
            }
            catch(Exception exp) 
            {
                WriteToLog("Fail: Open Read (IN) Endpoint " + epNum + " exception, " + exp.Message);
            }

            return epReader;
        }

        public int SetStreamConfig(int streamID, int mediaType, int width, int height, int fps)
        {
            switch (streamID)
            {
                case (int)StreamID.Color:
                    colorIsSetStreamConfig = true;
                    break;
                case (int)StreamID.Depth:
                    depthIsSetStreamConfig = true;
                    break;
            }

            return 0; 
        }

        public int GetActualConfig(int streamID, ref int mediaType, ref int width, ref  int height, ref int bpp, ref  int fps)
        {
            return 1; 
        }

        public int Init(int sourceType)
        {
            initialized = true;
            depthInitialized = true;
            colorInitialized = true;

            return 0; 
        }

        public int Init(int sourceType, int streamID)
        {
            initialized = true;

            switch (streamID)
            {
                case (int)StreamID.Color:
                    colorInitialized = true;
                    break;
                case (int)StreamID.Depth:
                    depthInitialized = true;
                    break;
            }

            return 0; 
        }

        public int Run()
        {
            depthRunStarts = true;

            return 0; 
        }

        public int Stop()
        {
            depthRunStarts = false;
            colorRunStarts = false;

            return 1;
        }

        public int Run(int streamID)
        {
            switch (streamID)
            {
                case (int)StreamID.Color:
                    colorRunStarts = true;
                    break;
                case (int)StreamID.Depth:
                    depthRunStarts = true;
                    break;
            }

            return 0; 
        }

        public int Run(int streamID, int dataSize)
        {
            try
            {
                switch (streamID)
                {
                    case (int)StreamID.Color:
                        //  -- using callback
                        //epTextureVideo.ReadBufferSize = dataSize;  --  when passing size, uncomment this line
                        epTextureVideo.DataReceivedEnabled = true;

                        ///// -- using continuous read
                        //colorThread = new Thread(ContinuousReadEP2);
                        //colorThread.Start();

                        colorRunStarts = true;
                        break;
                    case (int)StreamID.Depth:
                        /// -- using callback
                        //epIRVideo.ReadBufferSize = dataSize;  --  when passing size, uncomment this line
                        epIRVideo.DataReceivedEnabled = true;

                        
                        ///// -- using continuous read
                        //depthThread = new Thread(ContinuousReadEP1);
                        //depthThread.Start();
                         //this.m_dataSize = dataSize;
                        depthRunStarts = true;
                        break;
                }

                return 0;
            }
            catch { }

            return 0;
        }

        public int Stop(int streamID)
        {
            switch (streamID)
            {
                case (int)StreamID.Color:
                    epTextureVideo.Abort();
                    epTextureVideo.Flush();
                    epTextureVideo.DataReceivedEnabled = false;

                    colorRunStarts = false;
                    break;
                case (int)StreamID.Depth:
                    epIRVideo.Abort();
                    epIRVideo.Flush();
                    epIRVideo.DataReceivedEnabled = false;

                    depthRunStarts = false;
                    break;
            }

            return 1; 
        }

        private void ContinuousReadEP1()
        {
            ErrorCode ecRead;
            int transferredIn;
            byte[] readBuffer = new byte[epTextureVideo.ReadBufferSize];
            bool success;

            try
            {
                WriteToLog("Continuous ReadEP1 Start");

                while (depthThread.IsAlive)
                {
                    ecRead = epIRVideo.Read(readBuffer, 0, readBuffer.Length, 1000, out transferredIn);

                    success = ecRead == ErrorCode.Ok || ecRead == ErrorCode.Success || ecRead == ErrorCode.None;

                    if (ecRead != ErrorCode.None) throw new Exception("Continuous Read Failed.");

                    if (ecRead == ErrorCode.Ok || ecRead == ErrorCode.Success || ecRead == ErrorCode.None)
                    {
                        //// ---- Option 1  ---
                        unsafe
                        {
                            fixed (byte* bytePtr = readBuffer)
                            {
                                depthFrame = new IntPtr(bytePtr);
                            }
                        }

                        //// --- using Option 1 - will slow the frame rate ---
                        //depthFrame = Marshal.UnsafeAddrOfPinnedArrayElement(readBuffer, 0);
                        
                        m_frame_Size[(int)StreamID.Depth] = (uint)readBuffer.Length;
                        m_depthFrameCount++;
                        depthFrameArrived.Set();
                    }
                    else
                        depthFrame = IntPtr.Zero;
                }
            }
            catch (Exception exp)
            {
                WriteToLog("Continuous ReadEP1, exception: " + exp.Message);
            }
        }

        private void ContinuousReadEP2()
        {
            ErrorCode ecRead;
            int transferredIn;
            byte[] readBuffer = new byte[epTextureVideo.ReadBufferSize];
            bool success;

            try
            {
                WriteToLog("Continuous ReadEP2 Start");

                while (colorThread.IsAlive)
                {
                    ecRead = epTextureVideo.Read(readBuffer, 0, readBuffer.Length, 1000, out transferredIn);

                    success = ecRead == ErrorCode.Ok || ecRead == ErrorCode.Success || ecRead == ErrorCode.None;

                    if (!success) throw new Exception("Continuous Read Failed.");

                    if (success)
                    {
                        //// ---- Option 1 ---
                        unsafe
                        {
                            fixed (byte* bytePtr = readBuffer)
                            {
                                colorFrame = new IntPtr(bytePtr);
                            }
                        }

                        //// --- using Option 1 - will slow the frame rate ---
                        //colorFrame = Marshal.UnsafeAddrOfPinnedArrayElement(readBuffer, 0);

                        m_frame_Size[(int)StreamID.Color] = (uint)readBuffer.Length;
                        m_rgbFrameCount++;
                        colorFrameArrived.Set();
                    }
                    else
                        depthFrame = IntPtr.Zero;
                }
            }
            catch (Exception exp)
            {
                WriteToLog("Continuous ReadEP2, exception: " + exp.Message);
            }
        }

        private void OnDataReceived(object sender, EndpointDataEventArgs e)
        {
            try
            {
                //WriteToLog("OnDataReceived: Buffer size " + e.Count + " hit: " + dataCallbackIndex);

                m_reg_buff_Size = e.Count;

                reg_buff = new byte[e.Count];
                Array.Copy(e.Buffer, 0, reg_buff, 0, e.Count);

                dataArrived.Set();
            }
            catch (Exception exp)
            {
                WriteToLog("OnDataReceived exception: " + exp.Message);
            }
        }

        private void DefaultOnDataReceived(object sender, EndpointDataEventArgs e)
        {

        }

        private void PrintHeader(byte[] buffer)
        {
            string byteFormat = "";
            for (int i = 0; i < headerSize; i++)
            {
                byteFormat += string.Format("{0} ", buffer[i]);
            }

            WriteToLog(string.Format("header: {0}", byteFormat));
        }

        private void OnTextureFrameReceived(object sender, EndpointDataEventArgs e)
        {
            try
            {
                unsafe
                {
                    fixed (byte* bytePtr = &e.Buffer[headerSize])
                    {
                        colorFrame = new IntPtr(bytePtr);
                    }
                }

                m_frame_Size[(int)StreamID.Color] = (uint)(e.Count - headerSize);
                m_rgbFrameCount++;
                colorFrameArrived.Set();
            }
            catch (Exception exp)
            {
                WriteToLog("Exception, OnTextureFrameReceived: Buffer size " + e.Count + " hit: " + colorCallbackIndex + " excption: " + exp.Message);
            }
        }


        private void OnDepthFrameReceivedChanged(object sender, DataReceivedEnabledChangedEventArgs e)
        {
            try
            {
                if (!e.Enabled)
                {
                    switch (e.ErrorCode)
                    {
                        case ErrorCode.Win32Error:
                        case ErrorCode.Overflow:
                            epIRVideo.Flush();
                            epIRVideo.DataReceivedEnabled = true;
                            break;
                    }
                }
            }
            catch (Exception exp)
            {
                WriteToLog("Exception, OnDepthFrameReceivedChanged: error code " + e.ErrorCode + " hit: " + colorCallbackIndex + " excption: " + exp.Message);
            }
        }

        private void OnTextureFrameReceivedChanged(object sender, DataReceivedEnabledChangedEventArgs e)
        {
            try
            {
                if (!e.Enabled)
                {
                    switch (e.ErrorCode)
                    {
                        case ErrorCode.Win32Error:
                        case ErrorCode.Overflow:
                            epTextureVideo.Flush();    
                            epTextureVideo.DataReceivedEnabled = true;

                            break;
                    }
                }
            }
            catch (Exception exp)
            {
                WriteToLog("Exception, OnTextureFrameReceivedChanged: error code " + e.ErrorCode + " hit: " + colorCallbackIndex + " excption: " + exp.Message);
            }
        }

        private void OnDepthFrameReceived(object sender, EndpointDataEventArgs e)
        {
            try
            {
                //WriteToLog(e.Count.ToString());

                m_depthFrameCount++;
                m_frame_Size[(int)StreamID.Depth] = (uint)(e.Count - headerSize);

                if ((m_depthFrameCount) % Skip != 0)
                    return;
                              
                unsafe
                {
                    fixed (byte* bytePtr = &e.Buffer[headerSize])
                    {
                        depthFrame = new IntPtr(bytePtr);
                    }
                }
                
                depthFrameArrived.Set();
            }
            catch (Exception exp)
            {
                WriteToLog("Exception, OnDepthFrameReceived: Buffer size " + e.Count + " hit: " + colorCallbackIndex + " excption: " + exp.Message);
            }
        }

        public int GetFrame(ref IntPtr ptr)
        {
            return 1; 
        }

        public IntPtr GetFrame(int streamID)
        {
            switch (streamID)
            {
                case (int)StreamID.Color:
                    if (!colorFrameArrived.WaitOne(1000, false))
                    {
                        colorFrame = IntPtr.Zero;
                    }

                    colorFrameArrived.Reset();

                    return colorFrame; 
                    
                case (int)StreamID.Depth:
                    if (!depthFrameArrived.WaitOne(1000, false))
                    {
                        depthFrame = IntPtr.Zero;
                    }

                    depthFrameArrived.Reset();
                    
                    return depthFrame;
            }

            return IntPtr.Zero;
        }

        public int ReleaseBuffer(IntPtr buffer)
        {
            return 1; 
        }

        public int Release()
        {
            CloseDevice();
            return 1; 
        }

        public uint GetFrameNumber(int streamID)
        {
            uint frameNumber = 0;
            switch (streamID)
            {
                case (int)StreamID.Color:
                    frameNumber = m_rgbFrameCount;
                    break;
                case (int)StreamID.Depth:
                    frameNumber = m_depthFrameCount;
                    break;
            }

            return frameNumber; 
        }

        public uint GetFrameSize(int streamID)
        {
            return m_frame_Size[streamID];
        }

        public bool Initialized()
        {
            return initialized;
        }

        public bool WriteFPGARegister(int header, int regAddress, int regData)
        {
            try
            {
                int[] data = new int[3];
                data[0] = header;
                data[1] = regAddress;
                data[2] = regData;

                if (Write(data))
                {
                    int status = 1;
                    int returnData = GetRegData(ref status, header);

                    return (returnData == regData && status == 1);
                }
            }
            catch { }

            return false;
        }

        public bool ReadFPGARegister(int header, int regAddress, ref int data, ref int status)
        {
            try
            {
                int[] dataToWrite = new int[3]; 
                dataToWrite[0] = header;
                dataToWrite[1] = regAddress;

                if (Write(dataToWrite))
                {
                    status = 1;
                    data = GetRegData(ref status, header);

                    return true;
                }
            }
            catch (Exception exp)
            {
                string f = exp.Message;
            }

            return false;
        }

        private ErrorCode Write(ushort[] data)
        {
            ErrorCode ec = ErrorCode.UnknownError;

            try
            {
                if (MyUsbDevice == null) throw new Exception("Device Not Found.");

                int bytesWritten;

                byte[] dest = new byte[data.Length * sizeof(ushort)];
                Buffer.BlockCopy(data, 0, dest, 0, dest.Length);

                ec = m_pUsbEpRegOut.Write(dest, 1000, out bytesWritten);                
            }
            catch (Exception ex)
            {
                string f = ex.Message;
            }

            return ec;
        }

        private bool Write(int[] data)
        {
            ErrorCode ec = ErrorCode.UnknownError;

            try
            {
                if (MyUsbDevice == null) throw new Exception("Device Not Found.");

                int bytesWritten;

                byte[] dest = new byte[data.Length * sizeof(int)];
                Buffer.BlockCopy(data, 0, dest, 0, dest.Length);

                ec = m_pUsbEpRegOut.Write(dest, 1000, out bytesWritten);

                return (ec == ErrorCode.None) || (ec == ErrorCode.Success) || (ec == ErrorCode.Ok);
            }
            catch (Exception ex)
            {
                string f = ex.Message;
            }

            return false;
        }

        public bool WriteBufferToFPGARegister(ushort regAddress, ushort[] regData)
        {
            throw new Exception("Not implemented");
        }

        public bool WriteFPGARegister(ushort regAddress, ushort regData)
        {
            try
            {
                ushort[] data = new ushort[3];
                data[0] = 1 & ~0x7000;
                data[1] = regAddress;
                data[2] = regData;

                ErrorCode ec = Write(data);

                return (ec == ErrorCode.None) || (ec == ErrorCode.Success) || (ec == ErrorCode.Ok);
            }
            catch
            {
                return false;
            }
        }

        public bool ReadFPGARegister(ushort regAddress, ref ushort data, ref int status)
        {
            try
            {
                if (MyUsbDevice == null) throw new Exception("Device Not Found.");

                ushort[] dataToWrite = new ushort[2];
                dataToWrite[0] = 0x8000 | (1 & ~0x7000); 
                dataToWrite[1] = regAddress;

                ErrorCode ec = Write(dataToWrite);

                if ((ec == ErrorCode.None) || (ec == ErrorCode.Success) || (ec == ErrorCode.Ok))
                {
                    data = GetRegData();
                    
                    status = 1;
                    return true;
                }
                else if (ec == ErrorCode.IoTimedOut)
                    status = -1;
                else if (ec == ErrorCode.ReadFailed)
                    status = -1;
            }
            catch { }
            
            return false;
        }

        public bool ReadBufferFromFPGARegister(ushort regAddress, ref byte[] regData, ref int status, int size)
        {
            throw new Exception("Not implemented");
        }

        int GetRegData(ref int errorType, int header)
        {
            if (!dataArrived.WaitOne(1000, false))
            {
                errorType = -1;
                return errorType;
            }

            if (reg_buff == null)
            {
                errorType = -2;
                return errorType;
            }

            int action = (int)((header & 0xFF000000) >> 24);

            System.Threading.Thread.Sleep(10);

            dataArrived.Reset();

            if (m_reg_buff_Size == 12)  //  data 
            {
                int readHeader = BitConverter.ToInt32(new byte[] { reg_buff[0], reg_buff[1], reg_buff[2], reg_buff[3] }, 0);

                if (header == readHeader)
                {
                    errorType = 1;

                    // write
                    if (action == 0x80)
                    {
                        return BitConverter.ToInt32(reg_buff, 8);
                            //return errorType;
                    }

                    // read
                    if (action == 0x00)
                    {
                        return BitConverter.ToInt32(reg_buff, 8);
                    }
                }
                else
                {
                    errorType = 0;
                    return errorType;
                }
            }
            else  //  video stream
            {
                errorType = 2;
                return errorType;
            }

            return 1;
        }

        private ushort GetRegData()
        {
            return BitConverter.ToUInt16(reg_buff, 4);
        }

        private void InitLogger()
        {
            try
            {
                string logDir = @"c:\temp";
                string logFile = "usb_lib_logger.txt";

                if (!Directory.Exists(logDir))
                    Directory.CreateDirectory(logDir);

                logger = Path.Combine(logDir, logFile);
                if (!File.Exists(logger))
                    File.CreateText(logger);

                fileInfo = new FileInfo(logger);
            }
            catch { }
        }

        private void CloseEndpoint(UsbEndpointBase endPoint)
        {
            try
            {
                if (endPoint != null)
                {
                    WriteToLog(string.Format("Success: Close Endpoint {0}, type: {1}", endPoint.EpNum.ToString("x2"), endPoint.Type));

                    endPoint.Abort();
                    endPoint.Flush();
                    endPoint.Dispose();
                    endPoint = null;
                }
            }
            catch(Exception exp)
            {
                WriteToLog(string.Format("Failed: Close Endpoint {0}, exception: {1}, type: {2}", endPoint.EpNum.ToString("x2"), exp.Message, endPoint.Type));
            }
        }

        private void RemoveEndpointCallbackAndCloseEndpoint(UsbEndpointReader endPoint, EventHandler<EndpointDataEventArgs> readCallback)
        {
            try
            {
                if (endPoint != null)
                {
                    WriteToLog(string.Format("Success: RemoveEndpointCallback Endpoint {0}, type: {1}", endPoint.EpNum.ToString("x2"), endPoint.Type));

                    endPoint.DataReceivedEnabled = false;
                    endPoint.DataReceived -= readCallback;

                    CloseEndpoint(endPoint);
                }
            }
            catch (Exception exp)
            {
                WriteToLog(string.Format("Failed: RemoveEndpointCallback Endpoint {0}, exception: {1}, type: {2}", endPoint.EpNum.ToString("x2"), exp.Message, endPoint.Type));
            }
        }

        private void CloseDevice(bool closeAll = true)
        {
            try
            {
                if (main != null && main.IsAlive)
                    main.Abort();

                if (colorThread != null && colorThread.IsAlive)
                    colorThread.Abort();

                if (depthThread != null && depthThread.IsAlive)
                    depthThread.Abort();

                WriteToLog("Close Device");

                if (MyUsbDevice != null)
                {
                    if (MyUsbDevice.IsOpen)
                    {
                        //CloseEndpoint(epControl);

                        RemoveEndpointCallbackAndCloseEndpoint(epIRVideo, OnDepthFrameReceived);
                        RemoveEndpointCallbackAndCloseEndpoint(epTextureVideo, OnTextureFrameReceived);
                        RemoveEndpointCallbackAndCloseEndpoint(m_pUsbEpRegIn, OnDataReceived);
                        CloseEndpoint(m_pUsbEpRegOut);

                        IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;
                        if (!ReferenceEquals(wholeUsbDevice, null))
                        {
                            wholeUsbDevice.ReleaseInterface(0);

                            if (!closeAll)
                                wholeUsbDevice.ResetDevice();

                            wholeUsbDevice.Close();
                        }
                        
                        MyUsbDevice.Close();                     
                    }                                       
                }

                UsbDevice.Exit();
                closeEvent.Set();
            }            
            catch(Exception exp) 
            {
                WriteToLog(string.Format("Failed: CloseDevice, exception: {0}", exp.Message));
            }
        }

        private void WriteToLog(string message)
        {
            try
            {
                //  if file size is 10MB - reset the file by deleting the content
                if (fileInfo != null && fileInfo.Length >= 10485760)
                    File.WriteAllText(logger, string.Empty);

                message = string.Format("{0} --- {1} {2}", DateTime.Now, message, Environment.NewLine);
                File.AppendAllText(logger, message);
            }
            catch { }
        }          

        public bool IsInitialized 
        {
            get { return isInitialized; }
            set { isInitialized = value; }
        }

        public bool AutoDQ { get { return autoDQ; } }

        public bool RunStarts
        {
            get { return runStarts; }
            set { runStarts = value; }
        }

        public bool DepthRunStarts
        {
            get { return depthRunStarts; }
            set { depthRunStarts = value; }
        }

        public bool ColorRunStarts
        {
            get { return colorRunStarts; }
            set { colorRunStarts = value; }
        }

        public bool DepthIsInitialized
        {
            get { return depthIsInitialized; }
            set { depthIsInitialized = value; }
        }

        public bool ColorIsInitialized
        {
            get { return colorIsInitialized; }
            set { colorIsInitialized = value; }
        }

        public bool DepthIsSetStreamConfig
        {
            get { return depthIsSetStreamConfig; }
            set { depthIsSetStreamConfig = value; }
        }

        public bool ColorIsSetStreamConfig
        {
            get { return colorIsSetStreamConfig; }
            set { colorIsSetStreamConfig = value; }
        }

        public int Skip
        {
            get { return m_Skip; }
            set { m_Skip = value; }
        }
    }
}
